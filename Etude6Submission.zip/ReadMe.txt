@author William Wallace
@date 26/04/2020

EXPLANATION
Etude 6 - Quilting Bee is a problem that requires drawing an image of square panels. 

HOW TO RUN
To run Etude 6, open VSCode or a similar code editor and run by typing "python QuiltingBeeFinal.py"
without quotation marks while in the directory containing QuiltingBeeFinal.

For parsing a .txt file with the quilts specifications, ensure the file contains a
size an colour in the format of the test case below, for each square type. 
In a code editor, type "cat <text-filename-here> | python QuiltingBeeFinal.py" 
without quotation marks, and replacing the file in the pointy brackets. 

For more information, refer to the PDF outlining "Etude 6 - Quilting Bee" in the current folder. 

TEST CASE

1.0 31 180 50
0.8 133 0 255
0.3 0 80 255